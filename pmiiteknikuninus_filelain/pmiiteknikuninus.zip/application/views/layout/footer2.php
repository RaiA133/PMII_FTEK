<footer id="footer">
    <div class="container py-4">
        <div class="copyright">
            &copy; <strong><span>pmiiteknik_uninus</span></strong> <?= date('Y'); ?>
        </div>
        <div class="credits">
            Designed by <a class="fst-italic">Biro Media Rayon Teknik</a>
        </div>
    </div>
</footer>